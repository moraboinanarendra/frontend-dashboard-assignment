# Frontend Dashboard Assignment

## How to Run

1. Make sure you have **Node.js** and **npm** installed.
2. Clone the repository or download the ZIP.
3. Run the following commands:

```
npm install
npm start
```

This will start the app at `http://localhost:3000/`.
