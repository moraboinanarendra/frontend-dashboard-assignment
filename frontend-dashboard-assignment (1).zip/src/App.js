import React, { useState } from 'react';
import './App.css';

const initialData = [
  {
    categoryName: 'CSPM Executive Dashboard',
    widgets: [
      { name: 'Widget 1', text: 'Random text 1' },
      { name: 'Widget 2', text: 'Random text 2' }
    ]
  }
];

function App() {
  const [data, setData] = useState(initialData);
  const [search, setSearch] = useState('');
  const [widgetName, setWidgetName] = useState('');
  const [widgetText, setWidgetText] = useState('');

  const addWidget = (categoryIndex) => {
    if (!widgetName || !widgetText) return;
    const newData = [...data];
    newData[categoryIndex].widgets.push({ name: widgetName, text: widgetText });
    setData(newData);
    setWidgetName('');
    setWidgetText('');
  };

  const removeWidget = (categoryIndex, widgetIndex) => {
    const newData = [...data];
    newData[categoryIndex].widgets.splice(widgetIndex, 1);
    setData(newData);
  };

  const filteredWidgets = (widgets) =>
    widgets.filter(w =>
      w.name.toLowerCase().includes(search.toLowerCase()) ||
      w.text.toLowerCase().includes(search.toLowerCase())
    );

  return (
    <div className="App">
      <h1>Dashboard</h1>
      <input
        type="text"
        placeholder="Search widgets..."
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
      {data.map((category, catIdx) => (
        <div key={catIdx} className="category">
          <h2>{category.categoryName}</h2>
          <div className="widgets">
            {filteredWidgets(category.widgets).map((widget, idx) => (
              <div key={idx} className="widget">
                <strong>{widget.name}</strong>
                <p>{widget.text}</p>
                <button onClick={() => removeWidget(catIdx, idx)}>❌</button>
              </div>
            ))}
          </div>
          <div className="add-widget">
            <input
              placeholder="Widget Name"
              value={widgetName}
              onChange={e => setWidgetName(e.target.value)}
            />
            <input
              placeholder="Widget Text"
              value={widgetText}
              onChange={e => setWidgetText(e.target.value)}
            />
            <button onClick={() => addWidget(catIdx)}>+ Add Widget</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default App;
